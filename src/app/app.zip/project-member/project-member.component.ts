import { Component, OnInit } from '@angular/core';
import { FormBuilder} from '@angular/forms';
declare var $: any;

@Component({
  selector: 'app-project-member',
  templateUrl: './project-member.component.html',
  styleUrls: ['./project-member.component.css']
})
export class ProjectMemberComponent implements OnInit {

  addMemberForm;
  projectId=[];
  companyId=[];
  checkall=[];

 

  constructor(private formBuilder:FormBuilder) {

    this.addMemberForm=formBuilder.group({
      projectId:[''],
      companyId:[''],
      checkall:[''],
    

    });
   }

  ngOnInit() {
    this.projectId=this.getprojectId();
    this.companyId=this.getcompanyId();
    $(".ui.dropdown").dropdown();

    $("#checkall").change(function () {
      $(".checkitem").prop("checked", $(this).prop("checked"))
    })
    $(".checkitem").change(function () {
      if ($(this).prop("checked") == false) {
        $("#checkall").prop("checked", false)
      }
      if ($(".checkitem:checked").length == $(".checkitem").length) {
        $("#checkall").prop("checked", true)
      }
    })
  
  }
  getprojectId(){

    return [
      { id: '1', name: 'Kohinoor' },
      { id: '2', name: 'Godrej Trees' },
      { id: '3', name: 'Golf-Link' },
      { id: '4', name: 'Afcons' }
    ];
  }

  getcompanyId(){

    return[
      {id: '1', name:'L&T'},
      {id: '2', name:'Mahindra'},
      {id: '3', name:'TATA'},
      {id: '4', name:'OBR'},
      {id: '5', name:'Afcons'},
      {id: '6', name:'GemEngServ'},
    ]
  }
  addMember() 
  { 

    var projectId=this.addMemberForm.value.projectId;
    var companyId=this.addMemberForm.value.companyId;
    // console.log(this.addMemberForm.value);
    // console.log(this.addMemberForm.value);

    var projectMember={};

    projectMember['projectId ']=projectId;
    projectMember['companyId ']=companyId;

    console.log(projectMember);
  }
  ClickButton() {
    alert("Add Project Member Successfully");
}

}
