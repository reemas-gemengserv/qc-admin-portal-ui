import { Component, OnInit } from '@angular/core';
import { FormBuilder} from '@angular/forms';
declare var $: any;


@Component({
  selector: 'app-add-project-member',
  templateUrl: './add-project-member.component.html',
  styleUrls: ['./add-project-member.component.css']
})
export class AddProjectMemberComponent implements OnInit {

  addProjectMemberForm;
  projectId=[];
  companyId=[];
  checkall=[];


  constructor(private formBuilder:FormBuilder) {
    this.addProjectMemberForm=formBuilder.group({
      projectId:[''],
      companyId:[''],
      checkall:[''],
    });
   }

  ngOnInit() {
    this.projectId=this.getprojectId();
    this.companyId=this.getcompanyId();
    $(".ui.dropdown").dropdown();

    $("#checkall").change(function () {
      $(".checkitem").prop("checked", $(this).prop("checked"))
    })
    $(".checkitem").change(function () {
      if ($(this).prop("checked") == false) {
        $("#checkall").prop("checked", false)
      }
      if ($(".checkitem:checked").length == $(".checkitem").length) {
        $("#checkall").prop("checked", true)
      }
    })
  }
  getprojectId(){

    return [
      { id: '1', name: 'Kohinoor' },
      { id: '2', name: 'Godrej Trees' },
      { id: '3', name: 'Golf-Link' },
      { id: '4', name: 'Afcons' }
    ];
  }

  getcompanyId(){

    return[
      {id: '1', name:'L&T'},
      {id: '2', name:'Mahindra'},
      {id: '3', name:'TATA'},
      {id: '4', name:'OBR'},
      {id: '5', name:'Afcons'},
      {id: '6', name:'GemEngServ'},
    ]
  }
  addProjectMember() 
  { 

    var projectId=this.addProjectMemberForm.value.projectId;
    var companyId=this.addProjectMemberForm.value.companyId;
    // console.log(this.addMemberForm.value);
    // console.log(this.addMemberForm.value);

    var projectMember={};

    projectMember['projectId ']=projectId ;
    projectMember['companyId ']=companyId;

    console.log(projectMember);
  }
  ClickButton() {
    alert("Add Project Member Successfully");
}
}
